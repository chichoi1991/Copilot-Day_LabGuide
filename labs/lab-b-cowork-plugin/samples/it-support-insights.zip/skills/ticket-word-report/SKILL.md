---
name: ticket-word-report
description: |
  Generates a structured Microsoft Word (.docx) report from IT support ticket analysis results.
  Use when the user asks to create a "Word 보고서", "워드 문서", ".docx 보고서", "주간 보고서
  작성", "공식 보고서", "임원 보고용 문서", "Word document", "executive write-up", or any time
  the user requests a printable narrative document about IT support ticket analysis. This skill
  receives the structured analysis payload produced by `ticket-analysis` and emits a formatted
  Word document with cover page, executive summary, sectioned insights, recommended actions, and
  an appendix. Do not use for slide decks (use `ticket-ppt-report`) or interactive dashboards
  (use `ticket-dashboard-builder`).
license: MIT
metadata:
  author: Microsoft Demo
  version: "1.0"
---

# IT Support Word Report

## What This Skill Does

`ticket-analysis` 의 분석 페이로드를 받아 임원/현업 공유용 **Word 보고서(.docx)** 를 생성합니다.
Cowork 내장 문서 생성 기능을 사용하므로 본 스킬은 **문서 구조 + 섹션 콘텐츠 + 표/차트 지시** 를
마크다운 페이로드로 작성해 전달합니다.

## Inputs (분석 페이로드)

`ticket-analysis/SKILL.md` 의 출력 형식과 동일: 분석 개요 / 핵심 KPI 표 / 세그먼트 비교 표 /
인사이트 3개 + 권장 액션 2~3개 / 사용된 SQL.

## Workflow

1. **메타데이터 확정** — 보고서 제목, 작성일, 작성자(Cowork via IT Support Insights), 수신자.
   수신자/제목 미지정 시 한 번만 묻고 진행.
2. **문서 구조 빌드** — `references/word-template.md` 의 8-섹션 구조에 콘텐츠 슬롯 채우기.
3. **표/차트 처리** —
   - 표는 마크다운 표로 작성(Cowork가 Word 표로 변환).
   - 차트는 본문에 직접 넣지 않고 "<여기에 막대차트: 그룹별 SLA 위반율>" 같은 **자리표시자 캡션** 으로 명시.
4. **Cowork 내장 docx 생성 호출** — 구조화 마크다운을 문서 생성기에 전달. 직접 docx 바이너리 생성 금지.
5. **자기 검증** — 헤딩 레벨 일관(H1 표지/H2 섹션), 표 셀 수 일치, SQL 부록이 코드블록(고정폭).
6. **사용자 전달 및 메일 분기** — `IT지원내역_주간보고서_YYYYMMDD.docx` 로 전달. "메일로 보내줘" 면 `weekly-report-email` 에 첨부 위임.

## Output Format (문서 구조)

`references/word-template.md` 참고. 항상 다음 순서:

1. **표지** — 제목 / 부제(보고 주차·기간) / 작성일 / 데이터 출처
2. **Executive Summary** — 5~7줄 요약(핵심 발견 + 권장 액션 한 문장씩)
3. **분석 개요** — 목적, 보고 범위(주차), 표본 크기, 방법론
4. **핵심 KPI** — 표(전주 대비 Δ 포함) + 1줄 해석
5. **심층 분석** — 해당 패턴(P1~P7)별 sub-섹션(2~4개): SLA / MTTR / 재오픈 / CSAT 등
6. **주요 인사이트** — 번호 매김 3개, 각 1단락
7. **권장 액션** — 운영/품질/예방 카테고리, 각 액션의 타깃 + 기대 효과
8. **부록** — A. 데이터 스키마 요약 / B. 사용된 SQL / C. 용어집(SLA, MTTR, CSAT)

## Additional Resources

- **`references/word-template.md`** — 8개 섹션 구조화 마크다운 템플릿. 자리표시자(`__TITLE__`, `__EXEC_SUMMARY__` 등) 치환.

## Guardrails

- **공식 문서 톤** — 캐주얼한 이모지/속어 금지. "~합니다", "~로 분석됨" 객관적 어조.
- **수치 단위 명시** — 모든 숫자에 단위(건/%/시간/점). 큰 수는 천 단위 콤마.
- **PII 노출 금지** — `Assigned_Agent` 본문 노출 금지. 인원/그룹 단위로.
- **데이터 한계 명시** — 표지 또는 개요에서 "더미 데모 데이터" 1회.
- **이중 보고 금지** — 본 스킬은 Word만 생성. PPT/HTML 동시 생성은 사용자가 명시적으로 요청 시 각 스킬 별도 호출.

# Word Template — IT Support Weekly Report

`ticket-word-report` 가 Cowork 문서 생성기에 전달할 **구조화 마크다운 템플릿**.
자리표시자(`__...__`)를 분석 페이로드로 치환합니다.

---

```markdown
# __TITLE__
## __SUBTITLE__   <!-- 예: 주간 운영 보고 — W8 (2026-06-01~06-07) -->

작성일: __DATE__ | 작성자: Cowork · IT Support Insights | 데이터 출처: IT Support DB MCP (`tickets`, 22컬럼)

---

## 1. Executive Summary

__EXEC_SUMMARY__
<!-- 5~7줄. 이번 주 핵심 발견 + 권장 액션 한 문장씩. 더미 데모 데이터임을 1회 명시. -->

## 2. 분석 개요

- **목적**: __PURPOSE__
- **보고 범위**: __SCOPE__   <!-- 예: W8 단일 주 / W1~W8 추세 -->
- **표본 크기**: __SAMPLE__ 건
- **방법론**: IT Support DB MCP 의 read-only SQL 집계(SLA/MTTR/재오픈/CSAT)

## 3. 핵심 KPI

| 지표 | 값 | 전주 대비 | 비고 |
| --- | --- | --- | --- |
| 총 티켓 | __K1__ | __D1__ | |
| SLA 준수율 | __K2__ % | __D2__ | |
| 평균 MTTR | __K3__ h | __D3__ | |
| 재오픈율 | __K4__ % | __D4__ | |
| 평균 CSAT | __K5__ | __D5__ | |
| 자동해결율 | __K6__ % | __D6__ | |

> __KPI_NOTE__   <!-- 1줄 해석 -->

## 4. 심층 분석

### 4.1 SLA 위반 (P1)
__SEC_SLA__
<여기에 막대차트: 그룹별 SLA 위반율>

### 4.2 해결시간/병목 (P2)
__SEC_MTTR__
<여기에 가로막대차트: 카테고리별 MTTR P90>

### 4.3 재오픈·품질 / CSAT (P4·P5)
__SEC_QUALITY__

<!-- 보고 주제에 따라 채널(P6)·팀 성과(P7)·트렌드(P3) sub-섹션 추가 -->

## 5. 주요 인사이트

1. __INSIGHT_1__
2. __INSIGHT_2__
3. __INSIGHT_3__

## 6. 권장 액션

| 분류 | 액션 | 타깃 | 기대 효과 |
| --- | --- | --- | --- |
| 운영/리소스 | __A1__ | __T1__ | __E1__ |
| 프로세스/품질 | __A2__ | __T2__ | __E2__ |
| 셀프서비스/예방 | __A3__ | __T3__ | __E3__ |

## 7. 부록

### A. 데이터 스키마 요약
`tickets` (22컬럼): Ticket_ID, Created_At, Resolved_At, Report_Week, Category, Priority,
Status, Channel, Assignment_Group, SLA_Target_Hours, Resolution_Hours, SLA_Breached,
Reopened_Count, Auto_Resolved, CSAT_Score 외.

### B. 사용된 SQL
\`\`\`sql
__SQL__
\`\`\`

### C. 용어집
- **SLA**: 우선순위별 목표 해결시간(P1=4h, P2=8h, P3=24h, P4=72h)
- **MTTR**: 평균 해결 소요시간(Mean Time To Resolve)
- **CSAT**: 고객 만족도(1~5)
- **재오픈율**: Reopened_Count > 0 비율
```

---

## 작성 가이드

- 헤딩 레벨 일관: `#` 표지/제목, `##` 섹션, `###` sub-섹션.
- 표 셀 수가 헤더와 일치하는지 확인. 빈 값은 `-`.
- 차트는 본문에 직접 넣지 말고 `<여기에 ...차트: 설명>` 캡션으로 표기 → 사용자가 삽입.
- SQL 부록은 코드블록(고정폭). 단위는 모든 수치에.
- PII(`Assigned_Agent`) 본문 노출 금지, 인원/그룹 단위로만.

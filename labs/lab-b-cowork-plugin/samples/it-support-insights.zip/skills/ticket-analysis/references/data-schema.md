# IT Support DB — Data Schema Reference

`tickets` 테이블은 단일 평면 테이블로, **티켓당 1행**, 22개 컬럼입니다.
SQL 작성 시 컬럼명은 대소문자/언더스코어를 정확히 일치시켜야 합니다(DuckDB).
데이터는 최근 **8주(Report_Week 1~8)** 를 커버하며, 주차마다 의도된 이벤트/트렌드가 심어져 있습니다.

## 컬럼 사전

| # | 컬럼 | 타입 | 의미 | 단위/예시값 |
| -- | --- | --- | --- | --- |
| 1 | `Ticket_ID` | VARCHAR | 티켓 식별자 | `INC00001` |
| 2 | `Created_At` | TIMESTAMP | 접수 시각 | `2026-04-17 12:25:51` |
| 3 | `Resolved_At` | TIMESTAMP | 해결 시각 (미해결이면 NULL) | `2026-04-18 17:13:51` |
| 4 | `Report_Week` | INTEGER | 보고 주차 | `1`~`8` |
| 5 | `Week_Label` | VARCHAR | 주차 라벨(이벤트명 포함) | `W4 VPN/네트워크 대규모 장애` |
| 6 | `Week_Event` | VARCHAR | 주차 이벤트 키 | `baseline`,`patch_rollout`,`network_outage`… |
| 7 | `Category` | VARCHAR | 분류 (6종) | `Hardware`,`Software`,`Network`,`Account/Access`,`Email`,`Security` |
| 8 | `Subcategory` | VARCHAR | 세부 분류 (25종) | `VPN`,`Password Reset`,`Printer`,`Phishing`… |
| 9 | `Priority` | VARCHAR | 우선순위 (4종) | `P1`,`P2`,`P3`,`P4` |
| 10 | `Status` | VARCHAR | 상태 (5종) | `Open`,`In Progress`,`Resolved`,`Closed`,`Reopened` |
| 11 | `Channel` | VARCHAR | 접수 경로 (5종) | `Portal`,`Email`,`Phone`,`Teams`,`Walk-in` |
| 12 | `Assignment_Group` | VARCHAR | 처리 조직 (5종) | `Service Desk`,`Network`,`EUC`,`Security`,`Messaging` |
| 13 | `Assigned_Agent` | VARCHAR | 담당자 익명 ID (40명) | `AGT_012` |
| 14 | `Requester_Dept` | VARCHAR | 요청 부서 (9종) | `Finance`,`Sales`,`R&D`,`HR`… |
| 15 | `SLA_Target_Hours` | INTEGER | 우선순위별 SLA 목표 시간 | `4`(P1)/`8`(P2)/`24`(P3)/`72`(P4) |
| 16 | `First_Response_Hours` | DOUBLE | 첫 응답까지 소요 시간 | `0.4` (시간) |
| 17 | `Resolution_Hours` | DOUBLE | 해결 소요 시간(MTTR). 미해결이면 NULL | `11.5` (시간) |
| 18 | `SLA_Breached` | VARCHAR | SLA 위반 여부 | `Yes`/`No` (미해결은 `No`) |
| 19 | `Reopened_Count` | INTEGER | 재오픈 횟수 | `0`,`1`,`2` |
| 20 | `Reassignment_Count` | INTEGER | 재배정 횟수 | `0`~`4` |
| 21 | `Auto_Resolved` | VARCHAR | 자동/셀프 해결 여부 | `Yes`/`No` |
| 22 | `CSAT_Score` | DOUBLE | 고객 만족도 (응답한 종료 티켓만) | `1`~`5`, 미응답은 NULL |

## 주차별 이벤트 (Week_Event)

주간 보고의 스토리라인. 각 주에 의도된 신호가 데이터에 심어져 있습니다.

| 주 | `Week_Event` | 이벤트 | 데이터 신호 |
| -- | --- | --- | --- |
| W1 | `baseline` | 평상 주(기준선) | 베이스라인 |
| W2 | `patch_rollout` | Windows 보안패치 롤아웃 | `Software`/`Security`↑, 재오픈↑, CSAT↓ |
| W3 | `calm` | 안정화 | MTTR 안정, CSAT 회복 |
| W4 | `network_outage` | VPN/네트워크 대규모 장애 | `Network`·`P1` 폭증, SLA 위반율 급등, `Phone`↑ |
| W5 | `recovery` | 장애 회복(백로그 해소) | 잔여 백로그, CSAT 일시 하락 |
| W6 | `onboarding` | 분기 신입 온보딩 | `Account/Access`·`Password Reset`↑, `Walk-in`↑ |
| W7 | `phishing` | 피싱 캠페인 사고 | `Security`·`Email`↑, `P1`/`P2`↑ |
| W8 | `selfservice` | 셀프서비스 포털 도입 효과 | 볼륨↓, `Auto_Resolved`↑, CSAT↑ |

## 도메인 의미 노트

- **`Resolution_Hours IS NULL`** = 미해결 티켓(`Open`/`In Progress`/일부 `Reopened`). SLA·MTTR 집계에서 **분모에서 제외**해야 정확합니다(`NULLIF(...,0)` 병행).
- **SLA 위반 판정**은 `Resolution_Hours > SLA_Target_Hours`. 우선순위가 높을수록(P1=4h) 목표가 빡빡해 위반이 쉽습니다.
- **`Reopened_Count > 0`** 은 근본원인 미해결 신호 → CSAT를 크게 떨어뜨립니다(Q8 참조).
- **`Reassignment_Count`** 가 높을수록 MTTR이 길어집니다(라우팅 오류 → 지연).
- **`Auto_Resolved = 'Yes'`** 는 주로 `Account/Access`(Password Reset/MFA) 와 셀프서비스 포털(W8). 빠르고 SLA를 거의 안 깹니다.
- **`Assignment_Group = 'Network'`** 는 구조적으로 평균 MTTR이 높은 병목 경향(생성기 속도계수 반영).
- **`CSAT_Score`** 는 종료 티켓의 약 70%만 응답(약 40% NULL). 평균 계산 시 `WHERE CSAT_Score IS NOT NULL`.

## 자주 쓰는 값 분포 (참고)

```text
Category:          Account/Access, Software, Hardware, Network, Email, Security  (6종)
Priority:          P3(최다) > P4 > P2 > P1
Status:            Closed(최다), Resolved, In Progress, Open, Reopened
Channel:           Portal > Email > Phone ≈ Teams > Walk-in
Assignment_Group:  Service Desk(최다), Network, EUC, Security, Messaging
Requester_Dept:    Finance, Sales, R&D, HR, Marketing, Operations, Legal, IT, Customer Service (9종)
SLA_Target_Hours:  P1=4, P2=8, P3=24, P4=72
```

> 더미 데모 데이터입니다. 인사이트 보고 시 1회 명시하세요.

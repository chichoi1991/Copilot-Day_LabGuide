# SQL Cookbook — IT Support `tickets`

`run-sql` MCP 도구에 그대로 넣을 수 있는 **검증된 SELECT 쿼리** 모음입니다.
모두 단일 문장·읽기 전용이며, 로컬 MCP 서버의 `run-sql` 로 **12/12 실행 검증 완료**(2026-06-08).

> DuckDB 문법. 컬럼명은 대소문자/언더스코어 정확히 일치 필요.
> 주간 보고는 `Report_Week`(1~8) / `Week_Event` 로 GROUP BY 합니다.
> `Resolution_Hours` 가 NULL 인 행은 미해결 티켓 → SLA/MTTR 집계에서 분모 보정에 유의.

---

## Q1. 주차별 핵심 KPI (주간보고 표지)

```sql
SELECT Report_Week, Week_Event, COUNT(*) AS tickets,
       ROUND(100.0*SUM(CASE WHEN SLA_Breached='Yes' THEN 1 ELSE 0 END)
             /NULLIF(SUM(CASE WHEN Resolution_Hours IS NOT NULL THEN 1 ELSE 0 END),0),1) AS sla_breach_pct,
       ROUND(AVG(Resolution_Hours),1) AS avg_mttr_h,
       ROUND(AVG(CSAT_Score),2) AS avg_csat,
       ROUND(100.0*SUM(CASE WHEN Auto_Resolved='Yes' THEN 1 ELSE 0 END)/COUNT(*),1) AS auto_pct
FROM tickets
GROUP BY Report_Week, Week_Event
ORDER BY Report_Week;
```
> 8주 전체 추세를 한 표로. 주간 보고 1페이지 KPI 스트립의 기반.

---

## Q2. 주차 대비 변화 WoW (Week-over-Week)

```sql
WITH w AS (
  SELECT Report_Week,
         COUNT(*) AS tickets,
         ROUND(100.0*SUM(CASE WHEN SLA_Breached='Yes' THEN 1 ELSE 0 END)
               /NULLIF(SUM(CASE WHEN Resolution_Hours IS NOT NULL THEN 1 ELSE 0 END),0),1) AS breach_pct,
         ROUND(AVG(CSAT_Score),2) AS csat
  FROM tickets GROUP BY Report_Week
)
SELECT Report_Week, tickets,
       tickets - LAG(tickets) OVER (ORDER BY Report_Week) AS d_tickets,
       breach_pct,
       ROUND(breach_pct - LAG(breach_pct) OVER (ORDER BY Report_Week),1) AS d_breach,
       csat,
       ROUND(csat - LAG(csat) OVER (ORDER BY Report_Week),2) AS d_csat
FROM w ORDER BY Report_Week;
```
> "이번 주 vs 지난 주" 증감(Δ)을 자동 계산. 주간 보고의 핵심 메시지 도출용.

---

## Q3. SLA 위반 핫스팟 (그룹 × 우선순위) — P1

```sql
SELECT Assignment_Group, Priority, COUNT(*) AS cnt,
       ROUND(100.0*SUM(CASE WHEN SLA_Breached='Yes' THEN 1 ELSE 0 END)/COUNT(*),1) AS breach_pct,
       ROUND(AVG(Resolution_Hours),1) AS avg_mttr_h
FROM tickets
WHERE Resolution_Hours IS NOT NULL
GROUP BY Assignment_Group, Priority
HAVING COUNT(*) >= 5
ORDER BY breach_pct DESC, cnt DESC
LIMIT 12;
```
> 어느 조직의 어떤 우선순위가 SLA를 못 지키나. (검증 샘플: Network×P1 위반율 90.9%)
> 특정 주만 보려면 `WHERE` 에 `AND Report_Week = 4` 추가.

---

## Q4. 카테고리별 MTTR 백분위 (병목) — P2

```sql
SELECT Category, COUNT(*) AS cnt,
       ROUND(quantile_cont(Resolution_Hours,0.5),1) AS p50_h,
       ROUND(quantile_cont(Resolution_Hours,0.9),1) AS p90_h,
       ROUND(quantile_cont(Resolution_Hours,0.99),1) AS p99_h,
       ROUND(AVG(Resolution_Hours),1) AS avg_h
FROM tickets WHERE Resolution_Hours IS NOT NULL
GROUP BY Category ORDER BY p90_h DESC;
```
> 평균이 아닌 P90/P99 로 꼬리 지연(long tail) 을 드러냄. (검증: Network p90 113.6h)

---

## Q5. 처리 그룹별 부하·속도·품질 — P7

```sql
SELECT Assignment_Group, COUNT(*) AS cnt,
       ROUND(AVG(Resolution_Hours),1) AS avg_mttr_h,
       ROUND(AVG(First_Response_Hours),2) AS avg_frt_h,
       ROUND(100.0*SUM(CASE WHEN SLA_Breached='Yes' THEN 1 ELSE 0 END)
             /NULLIF(SUM(CASE WHEN Resolution_Hours IS NOT NULL THEN 1 ELSE 0 END),0),1) AS breach_pct,
       ROUND(AVG(CSAT_Score),2) AS avg_csat
FROM tickets
GROUP BY Assignment_Group ORDER BY cnt DESC;
```
> 처리량(부하) × MTTR × 첫응답 × 위반율 × CSAT 를 한 줄에. 팀 성과 비교/리소스 배분 근거.

---

## Q6. 재오픈율 높은 유형 (품질) — P4

```sql
SELECT Category, Subcategory, COUNT(*) AS cnt,
       SUM(CASE WHEN Reopened_Count>0 THEN 1 ELSE 0 END) AS reopened,
       ROUND(100.0*SUM(CASE WHEN Reopened_Count>0 THEN 1 ELSE 0 END)/COUNT(*),1) AS reopen_pct
FROM tickets
GROUP BY Category, Subcategory
HAVING COUNT(*) >= 8
ORDER BY reopen_pct DESC
LIMIT 12;
```
> 재오픈 = 근본원인 미해결 신호. 높은 유형은 KB/프로세스 개선 타깃.

---

## Q7. 채널별 효율 (자동해결·응답속도) — P6

```sql
SELECT Channel, COUNT(*) AS cnt,
       ROUND(100.0*SUM(CASE WHEN Auto_Resolved='Yes' THEN 1 ELSE 0 END)/COUNT(*),1) AS auto_pct,
       ROUND(AVG(First_Response_Hours),2) AS avg_frt_h,
       ROUND(AVG(Resolution_Hours),1) AS avg_mttr_h
FROM tickets
GROUP BY Channel ORDER BY cnt DESC;
```
> 셀프서비스(Portal) 자동해결율 vs 유인 채널(Phone/Walk-in) 비교. 채널 전환 효과 측정.

---

## Q8. CSAT 드라이버 (재오픈·SLA위반 영향) — P5

```sql
SELECT
  CASE WHEN Reopened_Count>0 THEN 'reopened' ELSE 'first_time' END AS reopen_flag,
  SLA_Breached,
  COUNT(*) AS cnt,
  ROUND(AVG(CSAT_Score),2) AS avg_csat
FROM tickets WHERE CSAT_Score IS NOT NULL
GROUP BY reopen_flag, SLA_Breached
ORDER BY reopen_flag, SLA_Breached;
```
> 만족도를 떨어뜨리는 요인 정량화. (검증: first_time+SLA준수 CSAT 4.17 → 재오픈·위반 시 급락)

---

## Q9. 카테고리 주간 추세 (피벗형) — P3

```sql
SELECT Category,
       SUM(CASE WHEN Report_Week=6 THEN 1 ELSE 0 END) AS w6,
       SUM(CASE WHEN Report_Week=7 THEN 1 ELSE 0 END) AS w7,
       SUM(CASE WHEN Report_Week=8 THEN 1 ELSE 0 END) AS w8,
       COUNT(*) AS total
FROM tickets
GROUP BY Category ORDER BY total DESC;
```
> 최근 3주 카테고리 증감을 가로로 펼침. 이벤트성 급증(예: 온보딩→Account/Access) 포착.
> 주 번호는 보고 시점에 맞춰 조정.

---

## Q10. 부서별 티켓 유입 + SLA 위반 — P3

```sql
SELECT Requester_Dept, COUNT(*) AS cnt,
       ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (),1) AS share_pct,
       ROUND(100.0*SUM(CASE WHEN SLA_Breached='Yes' THEN 1 ELSE 0 END)
             /NULLIF(SUM(CASE WHEN Resolution_Hours IS NOT NULL THEN 1 ELSE 0 END),0),1) AS breach_pct
FROM tickets
GROUP BY Requester_Dept ORDER BY cnt DESC;
```
> 어느 부서가 IT 부하를 많이 유발하나 + 그 부서가 SLA 영향을 받나.

---

## Q11. 최신주 미해결 백로그

```sql
SELECT Status, Priority, COUNT(*) AS cnt
FROM tickets
WHERE Report_Week = 8
  AND (Resolution_Hours IS NULL OR Status IN ('Open','In Progress','Reopened'))
GROUP BY Status, Priority
ORDER BY cnt DESC;
```
> 이번 주 넘어가는 미결 티켓을 우선순위별로. 다음 주 작업 부하 예측.
> `Report_Week` 값을 보고 대상 주로 변경.

---

## Q12. 요일·시간대 유입 (히트맵용) — P3

```sql
SELECT dayofweek(CAST(Created_At AS TIMESTAMP)) AS dow,
       CASE WHEN EXTRACT(hour FROM CAST(Created_At AS TIMESTAMP)) BETWEEN 9 AND 17
            THEN 'business' ELSE 'after_hours' END AS time_band,
       COUNT(*) AS cnt
FROM tickets
GROUP BY dow, time_band ORDER BY dow, time_band;
```
> 인입 피크(요일/업무시간) 파악 → 교대/상주 인력 배치 근거. `dow`: 0=일 ~ 6=토.

---

## 사용 팁

- 결과 행이 많으면 `LIMIT` 추가 또는 `GROUP BY` 로 요약.
- 비율은 `100.0 * SUM(CASE ...) / COUNT(*)` 패턴(정수 나눗셈 회피).
- SLA/MTTR 집계는 **미해결(`Resolution_Hours IS NULL`) 행을 분모에서 제외** — `NULLIF(... ,0)` 으로 0분모 방어.
- 백분위는 `quantile_cont(col, q)` (DuckDB).
- 특정 주만 분석하려면 어느 쿼리든 `WHERE Report_Week = N` (또는 `Week_Event = '...'`) 를 덧붙이면 됨.
- `run-sql` 은 단일 문장만 허용 — 두 결과가 필요하면 호출을 나눌 것.

# IT Support Ticket Analysis Patterns

`ticket-analysis` 가 자주 받는 분석 요청을 7가지 패턴으로 분류하고, 각 패턴별로
핵심 컬럼/추천 쿼리/해석 가이드를 정리합니다. 검증된 SQL은 `sql-cookbook.md` 에 있습니다.

> 이 데모는 **주간 보고(Weekly Report)** 가 기본 맥락입니다. 거의 모든 패턴은
> `Report_Week` / `Week_Event` 필터·그룹과 결합해 "이번 주" 또는 "주차 추세"로 좁힐 수 있습니다.

---

## P1. SLA 준수/위반 분석

**언제 사용**: "SLA 위반 분석", "SLA 못 지킨 티켓", "위반 핫스팟", "SLA breach".

**핵심 컬럼**: `SLA_Breached`, `SLA_Target_Hours`, `Resolution_Hours`, `Priority`, `Assignment_Group`, `Category`.

**추천 쿼리**: Q3(그룹×우선순위 핫스팟), Q1(주차별 위반율).

**해석 포인트**: 위반은 **우선순위가 높을수록(P1=4h 목표)** 쉽게 발생. 어느 *조직×우선순위* 조합이 위반을 주도하는지 핀포인트. 권장 액션은 "P1 에스컬레이션 경로 정비 / 병목 그룹 증원 / 목표시간 현실화".

**차트**: Doughnut(위반/준수 비율) + Bar(그룹별 위반율).

---

## P2. 해결시간(MTTR) 분석

**언제 사용**: "해결 시간", "처리 지연", "병목", "MTTR", "오래 걸리는 티켓".

**핵심 컬럼**: `Resolution_Hours`, `First_Response_Hours`, `Category`, `Assignment_Group`, `Reassignment_Count`.

**추천 쿼리**: Q4(카테고리별 P50/P90/P99), Q5(그룹별 평균 MTTR).

**해석 포인트**: **평균이 아닌 P90/P99** 로 꼬리 지연을 봐야 합니다. 평균은 멀쩡해도 P99가 길면 일부 티켓이 방치된 것. `Reassignment_Count` 와 MTTR의 상관도 확인.

**차트**: Horizontal Bar(카테고리별 P90) + Box/Scatter(분포).

---

## P3. 티켓 볼륨·트렌드 분석

**언제 사용**: "티켓 추세", "유입량", "피크 시간", "주별 증감", "부서별 유입".

**핵심 컬럼**: `Report_Week`, `Created_At`, `Category`, `Requester_Dept`, `Channel`.

**추천 쿼리**: Q2(WoW 증감), Q9(카테고리 주간 추세), Q10(부서별 유입), Q12(요일·시간대).

**해석 포인트**: 이벤트성 급증을 `Week_Event` 와 연결해 설명("W6 온보딩 → Account/Access 급증"). 피크 시간대는 인력 배치 근거.

**차트**: Line(주별 추세) + Stacked Bar(카테고리 구성) + Heatmap(요일×시간).

---

## P4. 재오픈/품질 분석

**언제 사용**: "재오픈 많은 유형", "다시 열린 티켓", "근본원인 미해결", "품질".

**핵심 컬럼**: `Reopened_Count`, `Category`, `Subcategory`, `Assignment_Group`.

**추천 쿼리**: Q6(재오픈율 높은 유형).

**해석 포인트**: 재오픈율이 높은 유형 = **첫 해결이 부실** → KB(지식베이스)/진단 절차/교육 개선 타깃. 특정 그룹에 몰리면 역량 이슈.

**차트**: Bar(유형별 재오픈율) + Pareto.

---

## P5. CSAT(만족도) 드라이버 분석

**언제 사용**: "만족도 분석", "CSAT 낮은 원인", "고객 불만 요인".

**핵심 컬럼**: `CSAT_Score`, `Reopened_Count`, `SLA_Breached`, `Resolution_Hours`.

**추천 쿼리**: Q8(재오픈·SLA위반별 CSAT).

**해석 포인트**: 만족도를 떨어뜨리는 두 요인은 보통 **재오픈** 과 **SLA 위반**. 정량 비교로 "재오픈 시 CSAT N점 하락" 같은 메시지 도출. `CSAT_Score IS NOT NULL` 필터 필수.

**차트**: Grouped Bar(재오픈×위반 조합별 평균 CSAT).

---

## P6. 채널/셀프서비스 효율 분석

**언제 사용**: "채널별 분석", "셀프서비스 효과", "자동해결율", "포털 vs 전화".

**핵심 컬럼**: `Channel`, `Auto_Resolved`, `First_Response_Hours`, `Resolution_Hours`.

**추천 쿼리**: Q7(채널별 자동해결율·응답속도), Q1(주차별 auto_pct로 W8 효과).

**해석 포인트**: 셀프서비스(Portal) 자동해결율이 높을수록 유인 채널(Phone/Walk-in) 부하↓. W8 셀프서비스 도입 전후 `auto_pct` 변화로 ROI 제시.

**차트**: Pie(채널 점유율) + Bar(채널별 자동해결율).

---

## P7. 에이전트/그룹 성과 분석

**언제 사용**: "팀별 성과", "그룹 비교", "처리량", "어느 팀이 느린가".

**핵심 컬럼**: `Assignment_Group`, `Assigned_Agent`, `Resolution_Hours`, `SLA_Breached`, `CSAT_Score`.

**추천 쿼리**: Q5(그룹별 부하·속도·품질·CSAT).

**해석 포인트**: 처리량(부하) × MTTR × 위반율 × CSAT를 함께 봐야 공정. 부하가 큰데 MTTR이 낮으면 우수, 부하가 작은데 위반율이 높으면 개선 대상. **개인(Assigned_Agent) 단위는 PII 민감** — 집계/익명 ID로만.

**차트**: Radar(그룹×다지표) + Bar(그룹별 처리량).

---

## 분석 흐름 권장 시퀀스

1. **세션 첫 호출**: `get-table-schema` 로 컬럼 확인(1회).
2. **분석 주제 확정**: 사용자 질문을 위 P1~P7 중 하나(또는 조합)에 매핑.
3. **주차 범위 결정**: 주간 보고면 최신주(W8) 또는 특정 주, 추세면 전체. `WHERE Report_Week = N` 추가.
4. **쿼리 실행**: `sql-cookbook.md` 의 해당 쿼리를 `run-sql` 로 호출.
5. **요약 추출**: 핵심 KPI 4~6개 + 세그먼트 비교 + 인사이트 3개 + 권장 액션 2~3개.
6. **출력 분기**: 채팅요약 / HTML / Word / PPT / 메일.

## 흔한 실수

- **미해결 티켓을 분모에 포함** — `Resolution_Hours IS NULL` 행을 SLA/MTTR 분모에서 빼야 함.
- **평균 MTTR만 보고** — P90/P99 꼬리를 놓침. 백분위 병행.
- **CSAT NULL 미필터** — 미응답(약 40%)을 0으로 오인하지 말 것.
- **개인 담당자 실명/지목** — `Assigned_Agent` 는 익명 ID, 집계 단위로만.
- **표본 크기 미공지** — 더미 데모 데이터임을 1회 명시.

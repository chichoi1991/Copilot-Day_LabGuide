---
name: ticket-analysis
description: |
  Analyzes IT helpdesk support tickets (SLA, MTTR, reopen, CSAT, channel, agent/group
  performance) from the IT Support DB MCP server and orchestrates downstream weekly-report
  generation. Use when the user asks to "티켓 분석", "헬프데스크 분석", "주간 보고", "SLA 위반",
  "해결 시간/MTTR", "재오픈 분석", "상담 만족도/CSAT", "티켓 추세", "팀별 성과", "helpdesk
  analysis", "ticket SLA", "weekly support report", "service desk insight", "incident trend".
  Also use as the entry point whenever the user wants a weekly HTML dashboard, Word report,
  PPT deck, or report email that involves IT support ticket data — this skill produces the
  underlying analysis and then routes to the appropriate output skill.
license: MIT
metadata:
  author: Microsoft Demo
  version: "1.0"
---

# IT Support Ticket Analysis

## What This Skill Does

IT 헬프데스크 티켓 22개 속성(SLA, 해결시간, 재오픈, 만족도, 채널, 처리조직 등)을 담은
IT Support DB MCP를 호출하여 사용자의 분석 질문에 답하고, 결과를 사용자 선호에 맞는
산출물(HTML 대시보드 / Word / PPT / 채팅 요약 / 주간 보고 메일)로 라우팅합니다.

본 스킬은 **분석 허브** 역할만 수행합니다. 산출물 생성은 다음 동료 스킬에 위임합니다.

- `ticket-dashboard-builder` — 반응형 HTML 대시보드
- `ticket-word-report` — Word(.docx) 보고서
- `ticket-ppt-report` — PowerPoint(.pptx) 보고서
- `weekly-report-email` — 주간 보고 메일 (Cowork 내장 Outlook으로 발송)

> **주간 보고가 기본 맥락입니다.** 데이터는 최근 8주(`Report_Week` 1~8)를 커버하며,
> 주차마다 의도된 이벤트(`Week_Event`: network_outage, phishing, selfservice 등)가 있습니다.

## Connector Tools (커넥터 2개)

본 스킬은 **두 개의 MCP 커넥터**를 사용합니다. 항상 도구 이름을 그대로 사용하세요.

### 1) `it-support-db-mcp` — 티켓 데이터 (기본)

| 도구 | 용도 | 우선순위 |
| --- | --- | --- |
| `get-table-schema` | `tickets` 테이블 컬럼 + 5행 샘플. SQL 생성 전 grounding 용 | 1 (먼저 호출) |
| `get-ticket-stats` | group_by(Report_Week/Category/Assignment_Group 등) 별 집계(count, SLA위반율, MTTR, CSAT …) | 2 |
| `list-tickets` | 단순 필터(Category/Priority/Report_Week 등)로 행 조회 | 2 |
| `run-sql` | 자유 형식 SELECT/WITH 쿼리(읽기 전용, 50,000행 캡). 복합 분석은 항상 이 도구 사용 | 3 |

### 2) `project-mgmt-mcp` — IT 프로젝트 데이터 (교차 분석)

| 도구 | 용도 |
| --- | --- |
| `list-projects` | 프로젝트 목록/필터(상태·연계주차·스폰서 등) |
| `get-project` | 코드(예: NET-2026)로 단건 상세(개요 + 마일스톤 + 리스크) |
| `get-project-by-week` | **보고 주차/이벤트로 연계 프로젝트 조회** — 티켓↔프로젝트 연결의 핵심 |
| `run-sql` | 자유 SELECT (테이블: projects / project_milestones / project_risks) |

> 두 서버 모두 `run-sql` 은 단일 `SELECT`/`WITH` 만 허용(`INSERT/UPDATE/DELETE/DROP/PRAGMA` 거부).

### 교차 분석 규칙 (언제 프로젝트 MCP를 부르나)
- 주차 이벤트(W4 장애, W2 패치, W6 온보딩, W7 피싱, W8 셀프서비스)를 **원인/맥락과 함께** 설명할 때
  → 해당 주차로 `get-project-by-week(week=N)` 또는 `get-project-by-week(event="<이벤트키>")` 호출.
- "왜 이 주에 티켓이 급증/개선됐나" 류 질문 → 티켓 지표(티켓 MCP) + 연계 프로젝트 상태·마일스톤·리스크(프로젝트 MCP)를 **함께 엮어** 답한다.
- 티켓의 `Week_Event` 값과 프로젝트의 `Linked_Event` 가 동일 키(network_outage 등)로 매칭된다.
- 프로젝트 단독 질의("진행 중 프로젝트 알려줘", "지연된 프로젝트")는 `list-projects`/`get-project` 만 사용.

## Workflow

### 1. 사용자 의도 분류

다음 3가지 축으로 의도를 정리합니다.

1. **분석 주제** (P1~P7 매핑은 `references/analysis-patterns.md` 참조)
   - SLA 위반 / 해결시간(MTTR) / 볼륨·트렌드 / 재오픈·품질 / CSAT 드라이버 / 채널·셀프서비스 / 팀 성과
2. **주차 범위** — 최신주(W8) 단일 보고인지, 특정 주(예: W4 장애 주)인지, 8주 추세인지.
3. **선호 산출물** — 사용자가 명시했다면 그대로, 아니라면 분석 완료 후 5번 단계에서 질문.

### 2. 스키마 확인

세션에서 처음 호출하는 경우 먼저 `get-table-schema` 를 1회 호출하여 컬럼·타입·샘플을 확보합니다. 이미 확보했다면 재호출하지 마세요.

### 3. 데이터 수집

복잡도에 따라 도구를 선택합니다.

- 단일 그룹 집계(주차별/카테고리별 KPI) → `get-ticket-stats`
- 필터링된 원시 행 미리보기 → `list-tickets`
- 다단계 집계, CTE, 백분위, WoW 증감 → `run-sql`

`run-sql` 사용 시:

- `references/sql-cookbook.md` 의 검증된 쿼리(Q1~Q12)를 출발점으로 사용하세요.
- 특정 주만 보려면 `WHERE Report_Week = N` 를 덧붙입니다.
- 행이 큰 결과는 **요약 통계 + 상위 N행** 으로 좁혀서 가져옵니다(토큰 절약).

### 3b. 프로젝트 교차 조회 (주차 사건의 맥락이 필요할 때)

주차 이벤트의 **원인·진행 맥락**을 설명해야 하면, 그 주차로 프로젝트 MCP를 호출합니다.

- `get-project-by-week(week=N)` 또는 `get-project-by-week(event="network_outage")` → 연계 프로젝트(상태·마일스톤·리스크) 확보.
- 예) W4 장애 분석 → `get-project-by-week(week=4)` → NET-2026(방화벽 교체 W9로 지연)을 근본 원인으로 연결.
- 8주 종합 보고 시 각 주요 이벤트 주(W2/W4/W6/W7/W8)에 대해 연계 프로젝트를 모아 "이벤트↔프로젝트" 매핑을 만든다.
- 프로젝트 데이터가 불필요한 단순 지표 질의에는 호출하지 않는다(토큰 절약).

### 4. 인사이트 추출

- **핵심 KPI 4~6개** — 총 티켓수 / SLA 준수율 / 평균 MTTR / 재오픈율 / 평균 CSAT / 자동해결율. 단위 필수(건, %, 시간, 점).
- **2~4개의 의미 있는 비교** — 주차 간(WoW), 그룹 간, 카테고리 간 차이.
- **연계 프로젝트 맥락** — 주요 사건 주차에 대해 "이 지표는 어떤 프로젝트와 연결되나"(원인/개선동력)를 1~2줄로.
- **권장 액션 2~3개** — 데이터 근거의 운영/프로세스/리소스 액션. 가능하면 연계 프로젝트(가속/리스크 완화)와 연결.

해석 가이드는 `references/analysis-patterns.md`, 프로젝트 맥락은 `references/project-context.md` 참고.

### 5. 산출물 형식 선택 (사용자가 명시하지 않은 경우)

사용자에게 다음과 같이 묻습니다:

> 분석 결과를 어떤 형태로 받아보시겠어요?
> 1. 채팅 요약만
> 2. 반응형 HTML 웹 대시보드 (`ticket-dashboard-builder`)
> 3. Word 보고서 (`ticket-word-report`)
> 4. PowerPoint 슬라이드 (`ticket-ppt-report`)
> 5. 주간 보고 메일로 발송 (`weekly-report-email`)

사용자가 처음 질문할 때 이미 형식을 지정했다면("PPT로", "메일로 보내줘") 묻지 말고 바로 진행합니다.

### 6. 산출물 생성 및 라우팅

| 사용자 선택 | 처리 |
| --- | --- |
| 채팅 요약만 | 아래 **출력 형식** 의 마크다운 요약 그대로 응답 |
| HTML 대시보드 | `ticket-dashboard-builder` 에 공통 페이로드 전달 |
| Word | `ticket-word-report` 에 공통 페이로드 전달 |
| PPT | `ticket-ppt-report` 에 공통 페이로드 전달 |
| 메일 발송 | `weekly-report-email` 에 공통 페이로드(+선택된 첨부 산출물) 전달 |

## 출력 형식 (채팅 요약 / 다른 스킬에 전달할 공통 페이로드)

분석을 마치면 항상 다음 구조의 마크다운을 산출합니다. 이 구조가 다른 출력 스킬이 기대하는 **공통 페이로드** 입니다.

```markdown
## 분석 개요
- **분석 주제**: <한 줄>
- **보고 주차/범위**: <예: W8(2026-06-01~06-07) 또는 W1~W8 추세>
- **표본 크기**: <N 건>
- **데이터 출처**: IT Support DB MCP (`tickets`, 22컬럼) + Project Mgmt MCP (프로젝트 5종) — 가상 데모 데이터

## 핵심 KPI
| 지표 | 값 | 전주 대비 | 비고 |
| --- | --- | --- | --- |
| 총 티켓 | ... | ... | ... |
| SLA 준수율 | ... % | ... | ... |
| 평균 MTTR | ... h | ... | ... |
| 재오픈율 | ... % | ... | ... |
| 평균 CSAT | ... | ... | ... |

## 세그먼트별 비교
| 세그먼트 | 건수 | 핵심 지표 1 | 핵심 지표 2 |
| --- | --- | --- | --- |
| ... | ... | ... | ... |

## 연계 프로젝트 (교차 분석 — 해당 시)
| 주차/이벤트 | 연계 프로젝트 | 상태 | 영향(원인/개선동력) |
| --- | --- | --- | --- |
| W4 / network_outage | NET-2026 네트워크 인프라 고도화 | 지연 | 방화벽 교체 W9 지연이 장애 근본 원인 |
| ... | ... | ... | ... |

## 주요 인사이트
1. ...
2. ...
3. ...

## 권장 액션
- **운영/리소스**: ...
- **프로세스/품질**: ...
- **셀프서비스/예방**: ...

## 사용된 쿼리
\`\`\`sql
-- run-sql 호출에 사용한 SELECT
SELECT ...
\`\`\`
```

## Additional Resources

추가 컨텍스트는 필요할 때만 로드합니다.

- **`references/data-schema.md`** — 22개 컬럼의 의미·단위·예시값 + 주차 이벤트표. SQL 작성 전이나 "어떤 데이터가 있어요?" 질문 시 로드.
- **`references/analysis-patterns.md`** — 7개 분석 패턴(P1~P7)과 해석 가이드 + 쿡북 쿼리 매핑. 분석 주제 매핑 시 로드.
- **`references/sql-cookbook.md`** — `run-sql` 에 바로 넣을 검증된 SELECT 12개(Q1~Q12). 복합 분석 시작 시 로드.
- **`references/project-context.md`** — 주차 이벤트(`Week_Event`)를 가상 IT 프로젝트(NET-2026, SECP-2026, SSP-2026, ONB-Q2, PHIS-2026)와 연계한 배경 서사. 보고서 내용을 인과적으로 풍부하게 채울 때 로드(가상 문서, 데모용).

## 가드레일

- **PII 가정 금지**: `Assigned_Agent` 는 익명 ID(`AGT_012`)입니다. 실제 인물 추정·외부 매핑·실명 지목 금지. 개인 성과는 집계 단위로만.
- **쓰기 작업 금지**: MCP 서버는 읽기 전용입니다. `INSERT/UPDATE/DELETE/DDL` 시도 금지(거부됨).
- **분모 보정**: SLA/MTTR 집계 시 미해결(`Resolution_Hours IS NULL`) 행을 분모에서 제외. CSAT는 `IS NOT NULL` 필터.
- **데이터 한계 공지**: 더미 데모 데이터임을 인사이트 보고 시 1회 명시.
- **단위 표기 필수**: 모든 수치에 단위(건 / % / 시간 / 점).
- **소스 인용**: 마지막에 사용한 `run-sql` 쿼리를 출력에 포함(재현성).

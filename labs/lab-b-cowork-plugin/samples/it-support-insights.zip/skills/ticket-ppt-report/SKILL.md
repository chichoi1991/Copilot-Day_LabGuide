---
name: ticket-ppt-report
description: |
  Generates a Microsoft PowerPoint (.pptx) slide deck from IT support ticket analysis results.
  Use when the user asks to build a "PPT 보고서", "파워포인트", "프레젠테이션", "슬라이드",
  "주간 보고 슬라이드", "임원 발표 자료", "보고용 슬라이드 덱", "slide deck", "PowerPoint
  presentation", or any visual presentation about IT support ticket analysis. This skill receives
  the structured analysis payload produced by `ticket-analysis` and emits a 9-slide deck spec
  (title / agenda / executive summary / analysis overview / KPI / segment / risk-hotspots /
  actions / appendix) for Cowork's built-in slide generator. Do not use for printable documents
  (use `ticket-word-report`) or interactive dashboards (use `ticket-dashboard-builder`).
license: MIT
metadata:
  author: Microsoft Demo
  version: "1.0"
---

# IT Support PPT Report (Consulting Style)

## What This Skill Does

`ticket-analysis` 의 분석 페이로드를 받아 8~10장 분량의 **컨설팅 보고서 형식 PowerPoint 덱(.pptx)** 을 생성합니다.
Cowork 내장 슬라이드 생성 기능을 사용하므로 본 스킬은 **슬라이드 시퀀스 + 각 슬라이드의
레이아웃·메시지·차트 종류** 를 명세로 작성해 전달합니다.

### 컨설팅 보고서 형식 (McKinsey/BCG 스타일)

- **액션 타이틀(Action Title)**: 각 슬라이드 헤드라인은 명사구가 아니라 **결론 문장**.
  (예: "네트워크 팀 P1 SLA 위반율이 90%를 넘어 즉각적 증원이 필요합니다")
- **핵심 메시지 콜아웃**: 헤드라인 아래 1줄 요약 띠 + 본문 우측/하단 **Takeaway 박스**(컬러 좌측 보더).
- **거버닝 띠(Governing thought)**: 표지·섹션에 얇은 컬러 룰.
- **출처 푸터(Source line)**: 모든 슬라이드 하단에 "Source: IT Support DB MCP + Project Mgmt MCP (가상 데모), n=…" + 페이지 번호.
- **여백·정렬**: 좌측 정렬, 충분한 여백, 슬라이드당 1메시지.

### Microsoft CI 하이라이트 팔레트

브랜드 4색을 **범주형 강조(KPI/세그먼트/차트 계열)** 에, 차콜/그레이를 텍스트·구조에 사용합니다.

| 토큰 | HEX | 용도 |
| --- | --- | --- |
| MS Blue | `#00A4EF` | 1차 하이라이트(핵심 수치·주 계열) |
| MS Green | `#7FBA00` | 긍정/개선 지표 |
| MS Yellow | `#FFB900` | 주의/중간 |
| MS Red | `#F25022` | 위험/악화(SLA 위반 등) |
| Charcoal | `#3C3C41` | 타이틀·본문 텍스트, 타이틀 띠 |
| Gray | `#737373` | 출처 푸터·캡션 |
| Light | `#F2F2F2` | 박스/표 배경 |

> 의미 매핑: SLA 위반·악화 = Red, 개선·달성 = Green, 중립 KPI = Blue, 경고 = Yellow.

### 헤더 규칙 (모든 본문 슬라이드)

- **표지(S1)**: 가로 구분 라인 없이 **CI 4색 블록**만.
- **제목·아젠다 외 모든 슬라이드**: 제목 텍스트 **바로 아래(약 15px 간격)** 에
  **얇은 회색 전체폭 라인**(좌우 ~30px 여백)을 둔다. (짧은 컬러 언더라인 아님)
- 하단: **Source 푸터**("Source: IT Support DB MCP + Project Mgmt MCP (가상 데모), n=…") + **페이지 번호**.

## Inputs (분석 페이로드)

`ticket-analysis/SKILL.md` 의 출력 형식과 동일(공통 페이로드에 **연계 프로젝트** 섹션 포함). 인과 서사를 풍부하게 하려면
허브 스킬이 **Project Mgmt MCP**(`get-project-by-week` / `get-project`)에서 가져온 프로젝트 데이터
(5종: NET-2026·SECP-2026·SSP-2026·ONB-Q2·PHIS-2026)를 사용해 주차 이벤트(`Week_Event`)를 프로젝트와 연계한다.
요약 스냅샷은 `ticket-analysis/references/project-context.md` 참고.

## Workflow

1. **메타 확정** — 덱 제목, 발표 일자, 발표자(또는 "Cowork · IT Support Insights"), 청중(임원/현업) 1회 확인.
2. **슬라이드 시퀀스 빌드** — `references/ppt-template.md` 의 패턴에 콘텐츠 채우기. 주간보고/종합 보고는 **12슬라이드**.
   | 분석 범위 | 슬라이드 수 |
   | --- | --- |
   | 단일 패턴(P1~P7 중 1개) | 8~9장 |
   | 주간보고(프로젝트 서사 포함) | **12장** |
   | 종합 임원 보고 | 12장 |
3. **프로젝트 연계** — 주차 이벤트를 프로젝트와 매핑(W4→NET-2026 장애, W2→SECP-2026 패치, W8→SSP-2026 셀프서비스 등).
   가상 서사임을 부록/푸터에 1회 명시.
4. **차트 지정** — 각 슬라이드 차트 자리에 **차트 종류 + 데이터 라벨/값** 명시.
   (예: "Line, X=주차, Y1=티켓수, Y2=SLA위반율, 데이터: W1 107/40.8 … W8 86/40.8")
5. **Cowork 내장 슬라이드 생성 호출** — 명세를 슬라이드 생성기에 전달. python-pptx 등 직접 생성 금지.
6. **자기 검증** — 슬라이드 번호 연속, **헤드라인이 명사로 끝나는 결론구**(예: "…최우선 과제", "…뚜렷한 개선"),
   제목 아래 전체폭 라인 존재, Source 푸터·페이지 번호, 차트와 표가 한 슬라이드에 겹치지 않게.
7. **사용자 전달 및 메일 분기** — `IT지원내역_주간보고.pptx` 로 전달. "메일로 보내줘" 면 `weekly-report-email` 에 첨부 위임.

## Output Format (덱 구조)

`references/ppt-template.md` 참고. 표준 **12-슬라이드 시퀀스** (컨설팅 형식 · 프로젝트 서사):

| # | 슬라이드 | 레이아웃 | 핵심 메시지 |
| -- | --- | --- | --- |
| 1 | 표지 | CI 4색 룰(라인 없음) | 보고서 제목 + 보고 주차/기간 + 발표자 |
| 2 | Executive Summary | Action Title + Key Messages | 컬러 마커 핵심 메시지 3개 + SO WHAT 콜아웃 |
| 3 | Agenda / 접근 | Title + Content | 다룰 5개 주제 |
| 4 | 분석 개요 & 컨텍스트 | Title + 프로젝트 카드 | 데이터 출처/표본 + 진행 5개 프로젝트 현황 |
| 5 | 이벤트↔프로젝트 연계 | Action Title + Table | 주차 이벤트 ↔ 프로젝트 ↔ 영향 매핑 |
| 6 | 핵심 KPI 추세 | Action Title + Chart + Takeaway | 8주 KPI Line(MS Blue/Red) + 핵심/주의 박스 |
| 7 | SLA 위반 핫스팟 | Action Title + Table | 그룹×우선순위 위반율, 위험행(≥80%) Red 강조 |
| 8 | 근본 원인 심층 | Action Title + 번호목록 + Takeaway | 장애 근본원인(NET-2026: VPN 정원·HA 미작동) |
| 9 | 주요 인사이트 | Action Title + 3-Column | CI 색 헤더의 인사이트 카드 3개(프로젝트 연계) |
| 10 | 권장 액션 | Action Title + 3-Column | 운영/품질/예방, 프로젝트 연계 컬러 보더 카드 |
| 11 | 리스크 & 로드맵 | Action Title + 목록 + Table | 잔존 리스크 + 다음 4주(W9~W12) 로드맵 |
| 12 | 부록 / Q&A | Title + Code | 사용된 SQL + 데이터 한계(더미·가상 서사·PII) 노트 |

모든 본문 슬라이드: **명사 종결 액션 타이틀 + 제목 아래 얇은 전체폭 라인 + 하단 Source 푸터 + 페이지 번호**.

## Additional Resources

- **`references/ppt-template.md`** — 슬라이드별 레이아웃·요소·예시 텍스트 + 차트 명세 + CI 색상 적용 패턴.
- **`../ticket-analysis/references/project-context.md`** — 가상 IT 프로젝트 5종 서사(주차 이벤트 연계).

## Guardrails

- **컨설팅 액션 타이틀(명사 종결)** — 헤드라인은 결론을 담되 **명사로 끝낸다**(예: "Network 팀 P1 SLA 위반율이 90%를 넘은 구조적 병목", "W4 장애 이후 W8까지 뚜렷한 개선"). "~합니다/~입니다" 같은 서술 종결과 단순 명사구("SLA 분석") 모두 지양.
- **헤더 라인** — 제목 아래 약 15px 간격으로 얇은 회색 전체폭 라인(좌우 ~30px 여백). 표지엔 라인 없이 CI 4색 블록만.
- **CI 색상 의미 일관** — 위험/악화=Red `#F25022`, 개선/달성=Green `#7FBA00`, 핵심수치=Blue `#00A4EF`, 경고=Yellow `#FFB900`. 본문 텍스트는 Charcoal `#3C3C41`.
- **출처 푸터 필수** — 모든 본문 슬라이드 하단에 "Source: IT Support DB MCP + Project Mgmt MCP (가상 데모), n=…" + 페이지 번호.
- **프로젝트 서사는 가상** — NET-2026 등 프로젝트/조직 서사는 데모용 가상임을 부록/푸터에 1회 명시.
- **텍스트 분량** — 슬라이드당 본문 100자 이내. 길면 표/글머리표로 분해.
- **차트 우선** — 수치는 가능하면 차트로. 표는 8행 이내.
- **수치 단위 일관성** — 모든 수치에 단위. 큰 수는 천 단위 콤마.
- **PII 노출 금지** — `Assigned_Agent` 노출 금지. 세그먼트는 집계 단위.

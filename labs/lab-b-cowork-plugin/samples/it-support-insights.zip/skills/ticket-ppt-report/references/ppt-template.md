# PPT Template — IT Support Weekly Deck (컨설팅 형식 · CI 색상 · 12슬라이드)

`ticket-ppt-report` 가 Cowork 슬라이드 생성기에 전달할 **12-슬라이드 명세 패턴**.
헤드라인은 **명사로 끝나는 결론구**, 차트는 종류+데이터 값까지 명시.
모든 본문 슬라이드: 제목 아래 **얇은 회색 전체폭 라인**(약 15px 간격, 좌우 ~30px 여백) + **Source 푸터** + 페이지 번호.
표지는 라인 없이 **CI 4색 블록**만.

## Microsoft CI 색상

| 토큰 | HEX | 의미 |
| --- | --- | --- |
| MS Blue | `#00A4EF` | 핵심 수치/중립 |
| MS Green | `#7FBA00` | 개선/달성 |
| MS Yellow | `#FFB900` | 주의 |
| MS Red | `#F25022` | 위험/악화 |
| Charcoal | `#3C3C41` | 제목·본문 |
| Gray | `#737373` | 푸터·캡션 |

---

## Slide 1 — 표지 (CI 4색 룰, 라인 없음)
- CI 4색 블록(Red/Green/Blue/Yellow)
- **제목**: __DECK_TITLE__ (예: "IT지원내역 주간 운영 보고")
- **부제**: W1–W8 · __PERIOD__ (MS Blue)
- 작은 글씨: "Cowork · IT Support Insights | Confidential — 데모용 더미 데이터"

## Slide 2 — Executive Summary (Action Title + Key Messages)
- **헤드라인(명사 종결)**: "셀프서비스 도입 후 회복세, 그러나 Network P1 병목이 최우선 과제"
- 컬러 원형 마커 3개:
  - 🔴 W4 네트워크 장애(NET-2026 지연)로 SLA 위반율 73% 정점
  - 🟢 W8 셀프서비스(SSP-2026) 도입 후 볼륨 최저·CSAT 4.38 최고
  - 🔵 Network P1 SLA 위반율 90.9% 구조적 병목
- 하단 **SO WHAT 콜아웃**(Yellow 보더): 권장 액션 효과 요약

## Slide 3 — Agenda (Title + Content, 라인 없음)
- 컬러 번호(01~05): SLA 현황·핫스팟 / MTTR·병목 / 이벤트↔프로젝트 / 재오픈·CSAT / 액션·리스크·로드맵

## Slide 4 — 분석 개요 & 컨텍스트 (Title + 프로젝트 카드)
- 좌: 데이터 출처(IT Support DB MCP, 22컬럼) · 표본 __SAMPLE__건 · 범위 W1–W8 · 지표 정의
- 우: **진행 5개 프로젝트 카드**(NET-2026/SECP-2026/SSP-2026/ONB-Q2/PHIS-2026, 컬러 보더 + 상태)

## Slide 5 — 이벤트 ↔ 프로젝트 연계 (Action Title + Table)
- **헤드라인**: "주차별 이벤트와 IT 프로젝트의 직접적 연계"
- 표: 주차 | 이벤트 | 연계 프로젝트 | 주요 영향(데이터)
- Takeaway(Blue): 악화(W4 NET/W2 SECP)·개선(W8 SSP) 모두 프로젝트 진척과 연동

## Slide 6 — 핵심 KPI 추세 (Action Title + Chart + Takeaway)
- **헤드라인**: "W4 장애 정점 이후 W8까지 SLA·볼륨의 뚜렷한 개선"
- **차트**: Line, X=주차(W1~W8), Y1=티켓수(MS Blue), Y2=SLA위반율%(MS Red)
  데이터: 티켓 [__TREND_TICKETS__], 위반율 [__TREND_BREACH__]
- 우측 Takeaway 2개: 핵심(Green) / 주의(Yellow)

## Slide 7 — SLA 위반 핫스팟 (Action Title + Table)
- **헤드라인**: "Network·EUC·Security의 P1에 집중된 SLA 위반"
- 표(8행 이내): 그룹 | 우선순위 | 건수 | 위반율 — **위반율 ≥80% 행은 Red 강조**
- Takeaway(Red): 80% 이상 즉시 조치, Network는 NET-2026 노후와 직결

## Slide 8 — 근본 원인 심층 (Action Title + 번호목록 + Takeaway)
- **헤드라인**: "VPN 인프라 노후화가 촉발한 W4 네트워크 장애"
- 번호 목록(Red): VPN 정원 3,000 vs 피크 4,200 / 방화벽 HA 미작동 / NET-2026 지연 / 결과 수치
- Takeaway(Red): 근본 대책(HA 모듈 우선 교체 + VPN 증설 + 수동 페일오버 런북)

## Slide 9 — 주요 인사이트 (Action Title + 3-Column)
- **헤드라인**: "다음 액션을 가리키는 세 가지 인사이트"
- 카드 3개(CI 색 헤더): 장애 충격(Red, NET-2026) / 구조적 병목(Blue) / 개선 레버(Green, SSP-2026)

## Slide 10 — 권장 액션 (Action Title + 3-Column)
- **헤드라인**: "프로젝트와 연계한 세 갈래 권장 액션"
- 컬러 좌측 보더 카드: 운영·NET-2026(Red) / 품질·SECP-2026(Yellow) / 예방·SSP-2026(Green)

## Slide 11 — 리스크 & 로드맵 (Action Title + 목록 + Table)
- **헤드라인**: "잔존 리스크와 다음 4주 로드맵"
- 좌: 잔존 리스크 3개(Red) / 우: 표 — 주(W9~W12) | 계획 | 프로젝트

## Slide 12 — 부록 / Q&A (Title + Code)
- 사용된 SQL(__SQL__)
- 데이터 한계: "더미 데모 데이터 · 프로젝트/조직 서사는 가상 참조 · Assigned_Agent 익명 ID · 미해결 티켓은 SLA/MTTR 분모 제외"

---

## 차트 명세 작성 패턴

> 슬라이드 생성기에 넘길 때 **차트 종류 + 축 + 데이터 라벨/값** 을 한 줄로:
> `"Line chart, X=주차, Y1=티켓수, Y2=SLA위반율(%), 데이터: W1 107/40.8 … W8 86/40.8"`

## 가이드

- **헤드라인은 명사로 끝낸다**(결론구). "~합니다/~입니다"(서술 종결), "SLA 분석"(단순 명사구) 모두 지양.
- 제목 아래 얇은 전체폭 라인(표지·아젠다 제외), Source 푸터·페이지 번호 일관 적용.
- 본문 텍스트 슬라이드당 100자 이내. 차트와 표를 같은 슬라이드에 함께 넣지 않기.
- 모든 수치에 단위, 큰 수는 천 단위 콤마. PII(`Assigned_Agent`) 노출 금지.
- 단일 패턴 보고는 5·8·11번을 생략해 8~9장으로 축약 가능.

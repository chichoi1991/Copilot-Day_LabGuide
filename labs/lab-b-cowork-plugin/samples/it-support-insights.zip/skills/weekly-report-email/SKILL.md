---
name: weekly-report-email
description: |
  Composes and sends a weekly IT support report email from the ticket analysis payload,
  delegating actual delivery to Cowork's built-in Outlook capability. Use when the user asks
  to "주간 보고 메일", "보고서 메일로 보내줘", "위클리 리포트 발송", "팀에 메일로", "이메일로
  공유", "send weekly report", "email the report", "mail this to the team". This skill turns
  the structured analysis payload produced by `ticket-analysis` into a clean, scannable email
  (HTML body with KPI summary, week-over-week highlights, top issues, and recommended actions),
  optionally attaching an HTML/Word/PPT artifact produced by the sibling output skills. It does
  NOT invent data — it only formats what the analysis skill provides, then hands off to Outlook.
license: MIT
metadata:
  author: Microsoft Demo
  version: "1.0"
---

# Weekly Report Email

## What This Skill Does

`ticket-analysis` 의 분석 페이로드를 받아 **주간 보고 이메일**을 구성하고, 실제 발송은
**Cowork 내장 Outlook 기능에 위임**합니다. 본 스킬은 메일의 **수신자 구성 + 제목 + 본문(HTML)
+ 첨부 지정**까지만 책임지며, SMTP/Graph를 직접 호출하지 않습니다.

스캔하기 쉬운 임원/팀 공유용 메일을 목표로 합니다 — 상단 3줄 요약, KPI 스트립,
WoW 하이라이트, 핫이슈 Top, 권장 액션.

## Inputs (분석 페이로드)

`ticket-analysis/SKILL.md` 의 **출력 형식** 섹션을 그대로 입력으로 받습니다.
누락이 있으면 직접 추론하지 말고 호출 측(허브)에 보강을 요청하세요. 특히 필요한 것:

- 보고 주차/범위 (예: W8, 2026-06-01~06-07)
- 핵심 KPI 표 (전주 대비 Δ 포함)
- 주요 인사이트 3개 + 권장 액션 2~3개
- (선택) 첨부할 산출물 파일 — HTML 대시보드 / Word / PPT

## Workflow

1. **수신자·제목 확정** — 사용자가 수신자를 명시하지 않았다면 **한 번만** 묻습니다.
   제목 기본형: `[IT지원내역 주간보고] W{주차} ({기간}) — SLA {준수율}%, 티켓 {건수}건`.
2. **본문 구성** — `references/email-template.md` 의 HTML 골격에 페이로드를 치환.
   본문은 **인라인 스타일 HTML**(메일 클라이언트 호환). 표는 단순 테이블로.
3. **첨부 결정** — 사용자가 대시보드/문서/덱을 함께 만들었다면 그 파일을 첨부 대상으로 지정.
   첨부가 OneDrive 공유 링크 방식이면 본문에 링크를 포함.
4. **발송 전 미리보기(필수)** — 발송 직전 사용자에게 다음을 보여주고 **명시적 확인**을 받습니다:
   - **받는 사람** (To/CC)
   - **제목**
   - **본문 전문** (정확한 텍스트)
   - 첨부 파일명
   민감 데이터가 포함되면 경고를 덧붙입니다.
5. **Outlook 위임 발송** — 확인 후 **Cowork 내장 Outlook 기능**으로 발송. 본 스킬에서
   직접 메일을 전송하지 마세요.
6. **결과 보고** — 발송 완료/실패를 사용자에게 알리고, 초안 저장을 원하면 Drafts 로 남깁니다.

## Output Format (이메일 구조)

`references/email-template.md` 골격을 따르되, 항상 다음 블록을 포함합니다.

| 블록 | 내용 |
| --- | --- |
| 제목 | `[IT지원내역 주간보고] W{주차} ({기간}) — 핵심 수치 1~2개` |
| 인사 + 3줄 요약 | 이번 주 한눈 요약(좋아진 점/나빠진 점/조치) |
| KPI 스트립 | 총 티켓 / SLA 준수율 / 평균 MTTR / 재오픈율 / CSAT + 전주 대비 Δ(▲▼) |
| WoW 하이라이트 | 전주 대비 가장 크게 변한 2~3개 항목 |
| 핫이슈 Top | SLA 위반·재오픈·병목 중 상위 3건(그룹/카테고리 명시) |
| 권장 액션 | 담당/기대효과를 곁들인 2~3개 |
| 맺음말 + 첨부 안내 | "상세는 첨부 대시보드/보고서 참조" + 데이터 한계 1줄 |

## Additional Resources

- **`references/email-template.md`** — 인라인 스타일 HTML 메일 골격. 자리표시자
  (`__SUBJECT__`, `__SUMMARY__`, `__KPI_ROWS__`, `__WOW__`, `__TOP_ISSUES__`, `__ACTIONS__`)를 치환.

## Guardrails

- **발송 전 확인 필수** — 수신자·제목·본문 전문을 보여주고 사용자 승인 후에만 발송. 무단 발송 금지.
- **개인정보 보호** — `Assigned_Agent` 등 개인 식별 정보는 본문에 노출 금지. 성과는 그룹/집계 단위로만.
- **민감도 경고** — 본문이 분석 세션의 분류된 데이터(MIP 라벨)를 포함하면, 발송 전 사용자에게 민감도 수준을 알리고 확인.
- **데이터 한계 명시** — 메일 하단에 "더미 데모 데이터" 1회 표기(데모 맥락).
- **직접 발송 금지** — 본 스킬은 본문/수신자/첨부만 구성. 실제 전송은 Cowork 내장 Outlook에 위임.
- **수치 단위·근거** — 모든 수치에 단위. 가능하면 본문 하단 또는 첨부에 사용된 SQL을 포함(재현성).
